// libvo/video_out.c

const vo_functions_t* init_best_video_out(char** vo_list){
  // ...
  for(i=0;video_out_drivers[i];i++){
      const vo_functions_t* video_driver=video_out_drivers[i];
      if(!video_driver->preinit(vo_subdevice))
          return video_driver; // success!
  }
  return NULL;
}

// libvo/vo_v4l2.c

static int
preinit (const char *arg)
{
  struct v4l2_output vout;
  struct v4l2_ext_controls ctrls;
  int err;

  if (subopt_parse (arg, subopts) != 0)
  {
    mp_msg (MSGT_VO, MSGL_FATAL,
            "\n-vo v4l2 command line help:\n"
            "Example: mplayer -vo v4l2:device=/dev/video16:output=2\n"
            "\nOptions:\n"
            "  device=/dev/videoX\n"
            "    Name of the MPEG decoder device file.\n"
            "  output=<0-...>\n"
            "    V4L2 id of the TV output.\n"
            "\n" );
    return -1;
  }

  if (!device)
    device = strdup (DEFAULT_MPEG_DECODER);

  v4l2_fd = open (device, O_RDWR);
  if (v4l2_fd < 0)
  {
    free (device);
    mp_msg (MSGT_VO, MSGL_FATAL, "%s %s\n", V4L2_VO_HDR, strerror (errno));
    return -1;
  }

  /* check for device hardware MPEG decoding capability */
  ctrls.ctrl_class = V4L2_CTRL_CLASS_MPEG;
  ctrls.count = 0;
  ctrls.controls = NULL;

  if (ioctl (v4l2_fd, VIDIOC_G_EXT_CTRLS, &ctrls) < 0)
  {
    free (device);
    mp_msg (MSGT_OPEN, MSGL_FATAL, "%s %s\n", V4L2_VO_HDR, strerror (errno));
    return -1;
  }

  /* list available outputs */
  vout.index = 0;
  err = 1;
  mp_msg (MSGT_VO, MSGL_INFO, "%s Available video outputs: ", V4L2_VO_HDR);
  while (ioctl (v4l2_fd, VIDIOC_ENUMOUTPUT, &vout) >= 0)
  {
    err = 0;
    mp_msg (MSGT_VO, MSGL_INFO, "'#%d, %s' ", vout.index, vout.name);
    vout.index++;
  }
  if (err)
  {
    mp_msg (MSGT_VO, MSGL_INFO, "none\n");
    free (device);
    return -1;
  }
  else
    mp_msg (MSGT_VO, MSGL_INFO, "\n");

  /* set user specified output */
  if (output != -1)
  {
    if (ioctl (v4l2_fd, VIDIOC_S_OUTPUT, &output) < 0)
    {
      mp_msg (MSGT_VO, MSGL_ERR,
              "%s can't set output (%s)\n", V4L2_VO_HDR, strerror (errno));
      free (device);
      return -1;
    }
  }

  /* display device name */
  mp_msg (MSGT_VO, MSGL_INFO, "%s using %s\n", V4L2_VO_HDR, device);
  free (device);

  /* display current video output */
  if (ioctl (v4l2_fd, VIDIOC_G_OUTPUT, &output) == 0)
  {
    vout.index = output;
    if (ioctl (v4l2_fd, VIDIOC_ENUMOUTPUT, &vout) < 0)
    {
      mp_msg (MSGT_VO, MSGL_ERR,
              "%s can't get output (%s).\n", V4L2_VO_HDR, strerror (errno));
      return -1;
    }
    else
      mp_msg (MSGT_VO, MSGL_INFO,
              "%s video output: %s\n", V4L2_VO_HDR, vout.name);
  }
  else
  {
    mp_msg (MSGT_VO, MSGL_ERR,
            "%s can't get output (%s).\n", V4L2_VO_HDR, strerror (errno));
    return -1;
  }

  return 0;
}
