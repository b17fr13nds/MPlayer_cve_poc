#!/bin/bash

echo "when done building, run './mplayer ./crash'" && sleep 2

docker build -t mplayer .
docker run --rm -v $PWD:/pwd --cap-add=SYS_PTRACE --security-opt seccomp=unconfined -d --name mplayer -i mplayer
docker exec -it mplayer /bin/bash
